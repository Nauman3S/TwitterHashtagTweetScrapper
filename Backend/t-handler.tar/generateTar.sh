rm -rf mesh-backend.tar
tar -cvf mesh-backend.tar *
