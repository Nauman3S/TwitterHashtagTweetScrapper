rm -rf tweets-handler.tar
tar -cvf tweets-handler.tar *
